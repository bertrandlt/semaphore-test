# meetup-ansible-paris-9

Ce repository contient les exemples utilisés lors du Meetup Ansible Paris #9. Vous pouvez retrouver le contenu de cette présentation à l'emplacement suivant : http://yannig.github.io/ansible-meetup-paris-9

Vous retrouverez les éléments suivants :

- un inventaire décrivant les containers Docker que nous allons créer ;
- des playbooks pour les différentes briques nécessaire à l'installation de mediawiki.

Avant de démarrer les différents playbooks, vous devrez télécharger l'archive mediawiki-1.26.2.tar.gz (https://releases.wikimedia.org/mediawiki/1.26/mediawiki-1.26.2.tar.gz) et le placer au même endroit que le fichier README.md.

Création des containers docker
------------------------------

